#include<stdio.h>
int main()
{
    int i,a,b,c,d,e,f,g;
    printf("enter the value of i");
    scanf("%d",&i);
    switch(i)
    {
        case 1:
               printf("enter the value of a,b");
               scanf("%d%d",&a,&b);
               c=(a+b);
               printf("%d",c);
               break;
        case 2:
                printf("enter the value of a,b");
                scanf("%d%d",&a,&b);
                d=(a-b);
                printf("%d",d);
                break;
        case 3:
                printf("enter the value of a,b");
                scanf("%d%d",&a,&b);
                e=(a*b);
                printf("%d",e);
                break;
        case 4:
                printf("enter the value of a,b");
                scanf("%d%d",&a,&b);
                f=(a/b);
                printf("%d",f);
                break;
        
    }
    return 0;
}