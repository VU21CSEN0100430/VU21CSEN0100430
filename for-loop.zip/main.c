/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int i=1;
    printf("enter the value of i");
    scanf("%d",&i);
    for(i=1;i<50;i++)
    printf("\n%d",i);

    return 0;
}
