/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
int even(int a,int b)
{
    printf("even");
    
    for(int i=a;i<=b;i++)
    {
     if(i%2==0)
     {
         printf("%d",i);
     }
    }
}
int odd(int a,int b)
{
    printf("odd numers");
    for(int j=a;j<=b;j++)
    {
        if(j%2!=0)
        {
            printf("%d",j);
        }
    }
}
int main()
{
    int n,m;
    printf("enter the value of n,m");
    scanf("%d%d",&n,&m);
    even(n,m);
    odd(n,m);
}