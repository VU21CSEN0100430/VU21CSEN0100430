/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
   int n,r,sum=0,temp;
   printf("enter the value of n");
   scanf("%d",&n);
   temp=n;
   while(n>0)
   {
       r=n%10;
       sum=sum*10+r;
       n=n/10;
   }
   n=temp;
   if(n==sum)
   {
       printf("enter the value is palindrome");
   }
   else
   {
       printf("enter the value is not a palindrome");
   }
    return 0;
}
