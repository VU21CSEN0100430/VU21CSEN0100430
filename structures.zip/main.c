/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

struct student
  {
      int rollnumber;
      char name[20];
      int age;
      float marks;
  };
  void main()
  {
      //Assining values to student strudctre .
      struct student s1={123,"charan",23,99.5};
      struct student s2={124,"bhuvan",25,99.0};
      // Assigning values to s2 using assingment operators
      printf("Details of s1: \n");
      printf("\nRoll Number : %d",s2.rollnumber);
      printf("\nName : %s",s2.name);
      printf("\nAge : %d",s2.age);
      printf("\nMarks : %f",s2.marks);
  }  
 