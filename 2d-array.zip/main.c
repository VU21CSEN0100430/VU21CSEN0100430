/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
//initilaization of 2D arrays
#include <stdio.h>

int main()
{
    int D2[3][3]={{1,2,3},{4,5,6},{7,8,9}};
    int i,j;
    for(i=0;i<3;i++)
     {
         for(j=0;j<3;j++)
         printf("%d",D2[i][j]);
     }
}
    

    

